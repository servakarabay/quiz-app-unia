package com.example.quizapp

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.*
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class Soru(
    val soru: String,
    val secenekler: List<String>,
    val dogruCevap: String
)



class MainActivity : AppCompatActivity() {

    private lateinit var sorular: List<Soru>
    private var index = 0
    private var skor = 0
    private lateinit var timer: CountDownTimer
    private lateinit var quizTimer: CountDownTimer
    private val soruSuresi = 10000L
    private val toplamSure = 40000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ana kısım
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        // son skor
        val tvSonSkor = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 16
            }
        }

        // sorunun süresi
        val tvSure = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // mevcut soru
        val tvProgress = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.parseColor("#3F51B5"))
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.START
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // soru metni
        val tvSoru = TextView(this).apply {
            textSize = 20f
            setTextColor(Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        layout.addView(tvSonSkor)
        layout.addView(tvSure)
        layout.addView(tvProgress)
        layout.addView(tvSoru)

        // buton
        val btnList = mutableListOf<Button>()
        repeat(4) {
            val btn = Button(this).apply {
                textSize = 20f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.DKGRAY)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = 16
                }
                setPadding(24, 24, 24, 24)
            }
            layout.addView(btn)
            btnList.add(btn)
        }

        setContentView(layout)

        //soru bankası
        val jsonSorular = """
        [
          {
            "soru": "İstanbul'un fethi ne zamandır?",
            "secenekler": ["1881", "1453", "1445", "1938"],
            "dogruCevap": "1453"
          },
          {
            "soru": "Türkçe dili kaç sesli harf içerir?",
            "secenekler": ["21", "11", "8", "15"],
            "dogruCevap": "8"
          },
          {
            "soru": "Hangisi bir asal sayıdır?",
            "secenekler": ["5", "15", "8", "91"],
            "dogruCevap": "5"
          },
          {
            "soru": "Ülkemizde kutlanan Demokrasi ve Milli Birlik Bayramı ne zamandır?",
            "secenekler": ["19 Mayıs", "23 Nisan", "9 Eylül", "15 Temmuz"],
            "dogruCevap": "15 Temmuz"
          }
        ]
        """.trimIndent()

        val gson = Gson()
        val soruTipi = object : TypeToken<List<Soru>>() {}.type
        sorular = gson.fromJson(jsonSorular, soruTipi)

        // son skoru
        val pref = getSharedPreferences("quiz", Context.MODE_PRIVATE)
        val oncekiSkor = pref.getInt("sonSkor", -1)
        if (oncekiSkor != -1) {
            tvSonSkor.text = "Son skorunuz: $oncekiSkor / ${sorular.size}"
        }

        // genel sınav süresi
        quizTimer = object : CountDownTimer(toplamSure, 1000) {
            override fun onTick(millisUntilFinished: Long) {}

            override fun onFinish() {
                timer.cancel()
                Toast.makeText(this@MainActivity, "Sınav süresi doldu!", Toast.LENGTH_LONG).show()
                finish()
            }
        }.start()

        // Soru gösterme fonksiyonu
        fun gosterSoru() {
            if (index >= sorular.size) {
                timer.cancel()
                quizTimer.cancel()
                pref.edit().putInt("sonSkor", skor).apply()
                Toast.makeText(this, "Skorunuz: $skor / ${sorular.size}", Toast.LENGTH_LONG).show()
                finish()
                return
            }

            val soru = sorular[index]
            tvProgress.text = "Soru ${index + 1} / ${sorular.size}"
            tvSoru.text = "${index + 1}. ${soru.soru}"

            for (i in 0 until 4) {
                val btn = btnList[i]
                btn.text = soru.secenekler[i]
                btn.setBackgroundColor(Color.DKGRAY)
                btn.setOnClickListener {
                    timer.cancel()
                    if (btn.text == soru.dogruCevap) {
                        skor++
                        btn.setBackgroundColor(Color.GREEN)
                    } else {
                        btn.setBackgroundColor(Color.RED)
                    }
                    Handler(Looper.getMainLooper()).postDelayed({
                        index++
                        gosterSoru()
                    }, 1000)
                }
            }

            timer = object : CountDownTimer(soruSuresi, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    tvSure.text = "Süre: ${millisUntilFinished / 1000} sn"
                }

                override fun onFinish() {
                    index++
                    gosterSoru()
                }
            }.start()
        }

        gosterSoru()
    }
}